def mostrar_catalogo(catalogo):
    print("\n Catálogo de productos:")
    for i, (nombre, precio) in enumerate(catalogo.items(), start=1):
        print(f"{i}. {nombre} - ${precio}")

def agregar_producto(carrito, catalogo):
    mostrar_catalogo(catalogo)
    opcion = int(input("Seleccione el número del producto: "))

    lista_productos = list(catalogo.items())

    if 1 <= opcion <= len(lista_productos):
        nombre, precio = lista_productos[opcion - 1]
        cantidad = int(input("Ingrese la cantidad: "))

        carrito.append({
            "nombre": nombre,
            "precio": precio,
            "cantidad": cantidad
        })

        print(" Producto agregado al carrito")
    else:
        print(" Opción inválida")

def eliminar_producto(carrito):
    if len(carrito) == 0:
        print(" Carrito vacío")
        return

    print("\n🛒 Carrito:")
    for i, producto in enumerate(carrito, start=1):
        print(f"{i}. {producto['nombre']}")

    opcion = int(input("Seleccione el número a eliminar: "))

    if 1 <= opcion <= len(carrito):
        eliminado = carrito.pop(opcion - 1)
        print(f" {eliminado['nombre']} eliminado")
    else:
        print(" Opción inválida")

def mostrar_factura(carrito):
    if len(carrito) == 0:
        print(" No hay productos en el carrito")
        return

    print("\n FACTURA")
    print("-------------------------")
    total = 0

    for producto in carrito:
        subtotal = producto["precio"] * producto["cantidad"]
        total += subtotal
        print(f"{producto['nombre']} - ${producto['precio']} x {producto['cantidad']} = ${subtotal}")

    print("-------------------------")
    print(f"TOTAL: ${total}")