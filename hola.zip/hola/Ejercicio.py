catalogo = {
    "Arroz": 3000,
    "Leche": 4000,
    "Pan": 2500,
    "Huevos": 10000,
    "Queso": 8000
}

carrito = []

# Menú principal
while True:
    print("\n--- MENÚ ---")
    print("1. Agregar producto")
    print("2. Eliminar producto")
    print("3. Ver factura")
    print("4. Salir")

    opcion = input("Seleccione una opción: ")
    
    
    if opcion == "1":
        agregar_producto(carrito, catalogo)

    elif opcion == "2":
        eliminar_producto(carrito)

    elif opcion == "3":
        mostrar_factura(carrito)

    elif opcion == "4":
        print("👋 Saliendo...")
        break

    else:
        print(" Opción inválida")